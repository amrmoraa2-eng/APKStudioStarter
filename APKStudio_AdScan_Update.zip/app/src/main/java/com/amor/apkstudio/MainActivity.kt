package com.amor.apkstudio

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.database.Cursor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Typeface
import android.graphics.Color
import android.util.TypedValue
import java.io.File
import java.util.zip.ZipFile
import java.nio.charset.Charset

class MainActivity : Activity() {
    private lateinit var resultText: TextView
    private val pickApkCode = 1001

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "APK Studio"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(26, 45, 75))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "أدوات آمنة لفحص ملفات تطبيقاتك"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(Color.rgb(70, 80, 95))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        val chooseButton = Button(this).apply {
            text = "اختيار ملف APK"
            setOnClickListener { chooseApk() }
        }
        root.addView(chooseButton, matchWrap())

        resultText = TextView(this).apply {
            text = "لم يتم اختيار ملف بعد."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.rgb(30, 40, 55))
            setPadding(dp(14), dp(18), dp(14), dp(18))
        }
        root.addView(resultText, matchWrap())

        val note = TextView(this).apply {
            text = "تحليل معلومات الحزمة والصلاحيات قراءة فقط. النتائج لا تثبت أن الملف آمن، ولا تتجاوز حماية التطبيقات أو أنظمة الدفع."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.rgb(90, 95, 105))
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(note, matchWrap())

        setContentView(scroll)
    }

    private fun chooseApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, pickApkCode)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickApkCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        resultText.text = "تم اختيار الملف، جارٍ تحليل معلوماته..."
        try {
            val name = queryName(uri) ?: "ملف APK"
            val size = try {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            } catch (_: Exception) { -1L }
            val sizeText = if (size >= 0) String.format("%.2f MB", size / (1024.0 * 1024.0)) else "غير معروف"

            val tempApk = File.createTempFile("apkstudio_", ".apk", cacheDir)
            contentResolver.openInputStream(uri)?.use { input ->
                tempApk.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("تعذرت قراءة الملف المحدد")

            val packageInfo = getArchivePackageInfo(tempApk.absolutePath)

            if (packageInfo == null) {
                tempApk.delete()
                resultText.text = "تم اختيار الملف، لكن أندرويد لم يتمكن من قراءة معلومات الحزمة.\n\nالاسم: $name\nالحجم: $sizeText\n\nتأكد أن الملف APK صالح وليس ملف XAPK أو APKS."
                return
            }

            val appInfo = packageInfo.applicationInfo
            if (appInfo != null) {
                appInfo.sourceDir = tempApk.absolutePath
                appInfo.publicSourceDir = tempApk.absolutePath
            }
            val label = try {
                if (appInfo != null) packageManager.getApplicationLabel(appInfo).toString() else "غير متاح"
            } catch (_: Exception) { "غير متاح" }
            val versionName = packageInfo.versionName ?: "غير محدد"
            val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) packageInfo.longVersionCode.toString() else packageInfo.versionCode.toString()
            val minSdk = appInfo?.minSdkVersion?.toString() ?: "غير محدد"
            val targetSdk = appInfo?.targetSdkVersion?.toString() ?: "غير محدد"
            val permissions = packageInfo.requestedPermissions ?: emptyArray()
            val permissionsText = if (permissions.isEmpty()) "لا توجد صلاحيات معلنة أو تعذر قراءتها" else permissions.joinToString("\n") { "• $it" }
            val adScan = scanAdLibraries(tempApk)
            tempApk.delete()

            resultText.text = "تحليل ملف APK\n\n" +
                "اسم الملف: $name\n" +
                "الحجم: $sizeText\n\n" +
                "اسم التطبيق: $label\n" +
                "اسم الحزمة: ${packageInfo.packageName ?: "غير متاح"}\n" +
                "الإصدار: $versionName\n" +
                "رقم الإصدار: $versionCode\n" +
                "أقل إصدار أندرويد: $minSdk\n" +
                "إصدار أندرويد المستهدف: $targetSdk\n\n" +
                "الصلاحيات المطلوبة (${permissions.size}):\n$permissionsText\n\n" +
                "فحص مؤشرات مكتبات الإعلانات:\n$adScan\n\n" +
                "تنبيه: الفحص يبحث عن مؤشرات نصية معروفة فقط؛ قد لا يكتشف كل المكتبات أو يعطي نتائج مؤكدة. لا يعني غياب المؤشرات عدم وجود إعلانات، ولا يثبت أن الملف آمن."
        } catch (e: Exception) {
            resultText.text = "تعذر تحليل الملف.\n\nالتفاصيل: ${e.localizedMessage ?: "خطأ غير معروف"}"
        }
    }


    /** Heuristic, read-only scan for known advertising SDK markers in APK contents. */
    private fun scanAdLibraries(apk: File): String {
        val signatures = linkedMapOf(
            "Google AdMob / Google Mobile Ads" to listOf("com/google/android/gms/ads", "com.google.android.gms.ads"),
            "Google Ad Manager" to listOf("com/google/ads/", "com.google.ads."),
            "Meta Audience Network" to listOf("com/facebook/ads", "com.facebook.ads"),
            "AppLovin" to listOf("com/applovin/", "com.applovin."),
            "Unity Ads" to listOf("com/unity3d/ads", "com.unity3d.ads"),
            " ironSource / LevelPlay" to listOf("com/ironsource/", "com.ironsource."),
            "Pangle" to listOf("com/bytedance/sdk/openadsdk", "com.bytedance.sdk.openadsdk"),
            "InMobi" to listOf("com/inmobi/", "com.inmobi."),
            "Start.io" to listOf("com/startapp/", "com.startapp.")
        )
        val found = linkedSetOf<String>()
        return try {
            ZipFile(apk).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory || !(entry.name.endsWith(".dex") || entry.name.endsWith(".xml") || entry.name.endsWith(".txt") || entry.name.endsWith(".json"))) continue
                    if (entry.size > 30L * 1024L * 1024L) continue
                    val bytes = zip.getInputStream(entry).use { it.readBytes() }
                    val content = String(bytes, Charset.forName("ISO-8859-1"))
                    for ((sdk, markers) in signatures) {
                        if (markers.any { content.contains(it, ignoreCase = true) }) found.add(sdk.trim())
                    }
                    if (found.size == signatures.size) break
                }
            }
            if (found.isEmpty()) {
                "لم يتم العثور على مؤشرات واضحة لمكتبات الإعلانات المعروفة. هذا لا يثبت خلو التطبيق من الإعلانات."
            } else {
                "تم العثور على مؤشرات محتملة:\n" + found.joinToString("\n") { "• $it" } +
                    "\n\nهذه مؤشرات وليست تأكيدًا نهائيًا، وقد تكون المكتبة موجودة دون استخدامها فعليًا."
            }
        } catch (e: Exception) {
            "تعذر فحص محتويات الملف: ${e.localizedMessage ?: "خطأ غير معروف"}"
        }
    }

    @Suppress("DEPRECATION")
    private fun getArchivePackageInfo(path: String): PackageInfo? {
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageArchiveInfo(path, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        } else {
            packageManager.getPackageArchiveInfo(path, PackageManager.GET_PERMISSIONS)
        }
    }

    private fun queryName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
