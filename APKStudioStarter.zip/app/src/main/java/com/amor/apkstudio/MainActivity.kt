package com.amor.apkstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.database.Cursor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Typeface
import android.graphics.Color
import android.util.TypedValue

class MainActivity : Activity() {
    private lateinit var resultText: TextView
    private val pickApkCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "APK Studio"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(26, 45, 75))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "أدوات آمنة لفحص ملفات تطبيقاتك"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(Color.rgb(70, 80, 95))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        val chooseButton = Button(this).apply {
            text = "اختيار ملف APK"
            setOnClickListener { chooseApk() }
        }
        root.addView(chooseButton, matchWrap())

        resultText = TextView(this).apply {
            text = "لم يتم اختيار ملف بعد."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.rgb(30, 40, 55))
            setPadding(dp(14), dp(18), dp(14), dp(18))
        }
        root.addView(resultText, matchWrap())

        val note = TextView(this).apply {
            text = "النسخة الأولية: اختيار ملف APK وعرض بياناته الأساسية فقط. إدارة المشتريات تتطلب ربطًا رسميًا بنظام الدفع داخل التطبيق الذي تملكه والتحقق من الشراء."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.rgb(90, 95, 105))
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(note, matchWrap())

        setContentView(scroll)
    }

    private fun chooseApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, pickApkCode)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickApkCode || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val name = queryName(uri) ?: "ملف APK"
        val size = try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        } catch (_: Exception) { -1L }
        val sizeText = if (size >= 0) String.format("%.2f MB", size / (1024.0 * 1024.0)) else "غير معروف"
        resultText.text = "تم اختيار الملف بنجاح\n\nالاسم: $name\nالحجم: $sizeText\n\nالخطوة التالية: إضافة قراءة معلومات الحزمة وتحليل Manifest لتطبيقاتك."
    }

    private fun queryName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
