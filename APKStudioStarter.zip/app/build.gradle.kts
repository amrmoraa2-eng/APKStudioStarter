plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.amor.apkstudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.amor.apkstudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
